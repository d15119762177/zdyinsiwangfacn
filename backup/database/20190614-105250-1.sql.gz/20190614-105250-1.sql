-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : pangolin
-- 
-- Part : #1
-- Date : 2019-06-14 10:52:50
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `hisi_admin_annex`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_annex`;
CREATE TABLE `hisi_admin_annex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联的数据ID',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '类型',
  `group` varchar(100) NOT NULL DEFAULT 'sys' COMMENT '文件分组',
  `file` varchar(255) NOT NULL COMMENT '上传文件',
  `hash` varchar(64) NOT NULL COMMENT '文件hash值',
  `size` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '附件大小KB',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '使用状态(0未使用，1已使用)',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `hash` (`hash`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 上传附件';


-- -----------------------------
-- Table structure for `hisi_admin_annex_group`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_annex_group`;
CREATE TABLE `hisi_admin_annex_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '附件分组',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `size` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '附件大小kb',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 附件分组';

-- -----------------------------
-- Records of `hisi_admin_annex_group`
-- -----------------------------
INSERT INTO `hisi_admin_annex_group` VALUES ('1', 'sys', '0', '0.00');

-- -----------------------------
-- Table structure for `hisi_admin_config`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_config`;
CREATE TABLE `hisi_admin_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统配置(1是，0否)',
  `group` varchar(20) NOT NULL DEFAULT 'base' COMMENT '分组',
  `title` varchar(20) NOT NULL COMMENT '配置标题',
  `name` varchar(50) NOT NULL COMMENT '配置名称，由英文字母和下划线组成',
  `value` text NOT NULL COMMENT '配置值',
  `type` varchar(20) NOT NULL DEFAULT 'input' COMMENT '配置类型()',
  `options` text NOT NULL COMMENT '配置项(选项名:选项值)',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文件上传接口',
  `tips` varchar(255) NOT NULL COMMENT '配置提示',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL COMMENT '状态',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 系统配置';

-- -----------------------------
-- Records of `hisi_admin_config`
-- -----------------------------
INSERT INTO `hisi_admin_config` VALUES ('1', '1', 'sys', '扩展配置分组', 'config_group', '', 'array', ' ', '', '请按如下格式填写：&lt;br&gt;键值:键名&lt;br&gt;键值:键名&lt;br&gt;&lt;span style=&quot;color:#f00&quot;&gt;键值只能为英文、数字、下划线&lt;/span&gt;', '2', '1', '1492140215', '1492140215');
INSERT INTO `hisi_admin_config` VALUES ('13', '1', 'base', '网站域名', 'site_domain', '', 'input', '', '', '', '2', '1', '1492140215', '1492140215');
INSERT INTO `hisi_admin_config` VALUES ('14', '1', 'upload', '图片上传大小限制', 'upload_image_size', '0', 'input', '', '', '单位：KB，0表示不限制大小', '3', '1', '1490841797', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('15', '1', 'upload', '允许上传图片格式', 'upload_image_ext', 'jpg,png,gif,jpeg,ico', 'input', '', '', '多个格式请用英文逗号（,）隔开', '4', '1', '1490842130', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('16', '1', 'upload', '缩略图裁剪方式', 'thumb_type', '2', 'select', '1:等比例缩放
2:缩放后填充
3:居中裁剪
4:左上角裁剪
5:右下角裁剪
6:固定尺寸缩放
', '', '', '5', '1', '1490842450', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('17', '1', 'upload', '图片水印开关', 'image_watermark', '1', 'switch', '0:关闭
1:开启', '', '', '6', '1', '1490842583', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('18', '1', 'upload', '图片水印图', 'image_watermark_pic', '', 'image', '', '', '', '7', '1', '1490842679', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('19', '1', 'upload', '图片水印透明度', 'image_watermark_opacity', '50', 'input', '', '', '可设置值为0~100，数字越小，透明度越高', '8', '1', '1490857704', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('20', '1', 'upload', '图片水印图位置', 'image_watermark_location', '9', 'select', '7:左下角
1:左上角
4:左居中
9:右下角
3:右上角
6:右居中
2:上居中
8:下居中
5:居中', '', '', '9', '1', '1490858228', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('21', '1', 'upload', '文件上传大小限制', 'upload_file_size', '0', 'input', '', '', '单位：KB，0表示不限制大小', '1', '1', '1490859167', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('22', '1', 'upload', '允许上传文件格式', 'upload_file_ext', 'doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip', 'input', '', '', '多个格式请用英文逗号（,）隔开', '2', '1', '1490859246', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('23', '1', 'upload', '文字水印开关', 'text_watermark', '0', 'switch', '0:关闭
1:开启', '', '', '10', '1', '1490860872', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('24', '1', 'upload', '文字水印内容', 'text_watermark_content', '', 'input', '', '', '', '11', '1', '1490861005', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('25', '1', 'upload', '文字水印字体', 'text_watermark_font', '', 'file', '', '', '不上传将使用系统默认字体', '12', '1', '1490861117', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('26', '1', 'upload', '文字水印字体大小', 'text_watermark_size', '20', 'input', '', '', '单位：px(像素)', '13', '1', '1490861204', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('27', '1', 'upload', '文字水印颜色', 'text_watermark_color', '#000000', 'input', '', '', '文字水印颜色，格式:#000000', '14', '1', '1490861482', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('28', '1', 'upload', '文字水印位置', 'text_watermark_location', '7', 'select', '7:左下角
1:左上角
4:左居中
9:右下角
3:右上角
6:右居中
2:上居中
8:下居中
5:居中', '', '', '11', '1', '1490861718', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('29', '1', 'upload', '缩略图尺寸', 'thumb_size', '300x300;500x500', 'input', '', '', '为空则不生成，生成 500x500 的缩略图，则填写 500x500，多个规格填写参考 300x300;500x500;800x800', '4', '1', '1490947834', '1491040778');
INSERT INTO `hisi_admin_config` VALUES ('30', '1', 'sys', '开发模式', 'app_debug', '0', 'switch', '0:关闭
1:开启', '', '&lt;strong class=&quot;red&quot;&gt;生产环境下一定要关闭此配置&lt;/strong&gt;', '3', '1', '1491005004', '1492093874');
INSERT INTO `hisi_admin_config` VALUES ('31', '1', 'sys', '页面Trace', 'app_trace', '0', 'switch', '0:关闭
1:开启', '', '&lt;strong class=&quot;red&quot;&gt;生产环境下一定要关闭此配置&lt;/strong&gt;', '4', '1', '1491005081', '1492093874');
INSERT INTO `hisi_admin_config` VALUES ('33', '1', 'sys', '富文本编辑器', 'editor', 'umeditor', 'select', 'ueditor:UEditor
umeditor:UMEditor
kindeditor:KindEditor
ckeditor:CKEditor', '', '', '0', '1', '1491142648', '1492140215');
INSERT INTO `hisi_admin_config` VALUES ('35', '1', 'databases', '备份目录', 'backup_path', './backup/database/', 'input', '', '', '数据库备份路径,路径必须以 / 结尾', '0', '1', '1491881854', '1491965974');
INSERT INTO `hisi_admin_config` VALUES ('36', '1', 'databases', '备份分卷大小', 'part_size', '20971520', 'input', '', '', '用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '0', '1', '1491881975', '1491965974');
INSERT INTO `hisi_admin_config` VALUES ('37', '1', 'databases', '备份压缩开关', 'compress', '1', 'switch', '0:关闭
1:开启', '', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '0', '1', '1491882038', '1491965974');
INSERT INTO `hisi_admin_config` VALUES ('38', '1', 'databases', '备份压缩级别', 'compress_level', '4', 'radio', '1:最低
4:一般
9:最高', '', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '0', '1', '1491882154', '1491965974');
INSERT INTO `hisi_admin_config` VALUES ('39', '1', 'base', '网站状态', 'site_status', '1', 'switch', '0:关闭
1:开启', '', '站点关闭后将不能访问，后台可正常登录', '1', '1', '1492049460', '1494690024');
INSERT INTO `hisi_admin_config` VALUES ('40', '1', 'sys', '后台管理路径', 'admin_path', 'admin.php', 'input', '', '', '必须以.php为后缀', '1', '1', '1492139196', '1492140215');
INSERT INTO `hisi_admin_config` VALUES ('41', '1', 'base', '网站标题', 'site_title', 'HisiPHP应用市场', 'input', '', '', '网站标题是体现一个网站的主旨，要做到主题突出、标题简洁、连贯等特点，建议不超过28个字', '6', '1', '1492502354', '1494695131');
INSERT INTO `hisi_admin_config` VALUES ('42', '1', 'base', '网站关键词', 'site_keywords', 'hisiphp,hisiphp框架,php开源框架', 'input', '', '', '网页内容所包含的核心搜索关键词，多个关键字请用英文逗号&quot;,&quot;分隔', '7', '1', '1494690508', '1494690780');
INSERT INTO `hisi_admin_config` VALUES ('43', '1', 'base', '网站描述', 'site_description', '', 'textarea', '', '', '网页的描述信息，搜索引擎采纳后，作为搜索结果中的页面摘要显示，建议不超过80个字', '8', '1', '1494690669', '1494691075');
INSERT INTO `hisi_admin_config` VALUES ('44', '1', 'base', 'ICP备案信息', 'site_icp', '', 'input', '', '', '请填写ICP备案号，用于展示在网站底部，ICP备案官网：&lt;a href=&quot;http://www.miibeian.gov.cn&quot; target=&quot;_blank&quot;&gt;http://www.miibeian.gov.cn&lt;/a&gt;', '9', '1', '1494691721', '1494692046');
INSERT INTO `hisi_admin_config` VALUES ('45', '1', 'base', '站点统计代码', 'site_statis', '&lt;script&gt;alert(\'a\')&lt;/script&gt;', 'textarea', '', '', '第三方流量统计代码，前台调用时请先用 htmlspecialchars_decode函数转义输出', '10', '1', '1494691959', '1494694797');
INSERT INTO `hisi_admin_config` VALUES ('46', '1', 'base', '网站名称', 'site_name', '蓝鼎网络', 'input', '', '', '将显示在浏览器窗口标题等位置', '3', '1', '1494692103', '1494694680');
INSERT INTO `hisi_admin_config` VALUES ('47', '1', 'base', '网站LOGO', 'site_logo', '', 'image', '', '', '网站LOGO图片', '4', '1', '1494692345', '1494693235');
INSERT INTO `hisi_admin_config` VALUES ('48', '1', 'base', '网站图标', 'site_favicon', '', 'image', '', '/admin/annex/favicon', '又叫网站收藏夹图标，它显示位于浏览器的地址栏或者标题前面，&lt;strong class=&quot;red&quot;&gt;.ico格式&lt;/strong&gt;，&lt;a href=&quot;https://www.baidu.com/s?ie=UTF-8&amp;wd=favicon&quot; target=&quot;_blank&quot;&gt;点此了解网站图标&lt;/a&gt;', '5', '1', '1494692781', '1494693966');
INSERT INTO `hisi_admin_config` VALUES ('49', '1', 'base', '手机网站', 'wap_site_status', '1', 'switch', '0:关闭
1:开启', '', '如果有手机网站，请设置为开启状态，否则只显示PC网站', '2', '1', '1498405436', '1498405436');
INSERT INTO `hisi_admin_config` VALUES ('50', '1', 'sys', '云端推送', 'cloud_push', '0', 'switch', '0:关闭
1:开启', '', '关闭之后，无法通过云端推送安装扩展', '5', '1', '1504250320', '1504250320');
INSERT INTO `hisi_admin_config` VALUES ('51', '0', 'base', '手机网站域名', 'wap_domain', 'ms.hisiphp.cn', 'input', '', '', '手机访问将自动跳转至此域名', '2', '1', '1504304776', '1504304837');
INSERT INTO `hisi_admin_config` VALUES ('52', '0', 'sys', '多语言支持', 'multi_language', '0', 'switch', '0:关闭
1:开启', '', '开启后你可以自由上传多种语言包', '6', '1', '1506532211', '1506532211');

-- -----------------------------
-- Table structure for `hisi_admin_hook`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_hook`;
CREATE TABLE `hisi_admin_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '系统插件',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `source` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子来源[plugins.插件名，module.模块名]',
  `intro` varchar(200) NOT NULL DEFAULT '' COMMENT '钩子简介',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 钩子表';

-- -----------------------------
-- Records of `hisi_admin_hook`
-- -----------------------------
INSERT INTO `hisi_admin_hook` VALUES ('1', '1', 'system_admin_index', '', '后台首页', '1', '1490885108', '1490885108');
INSERT INTO `hisi_admin_hook` VALUES ('2', '1', 'system_admin_tips', '', '后台所有页面提示', '1', '1490885108', '1490885108');
INSERT INTO `hisi_admin_hook` VALUES ('3', '1', 'system_annex_upload', '', '附件上传钩子，可扩展上传到第三方存储', '1', '1490885108', '1490885108');
INSERT INTO `hisi_admin_hook` VALUES ('4', '1', 'system_member_login', '', '会员登陆成功之后的动作', '1', '1490885108', '1490885108');
INSERT INTO `hisi_admin_hook` VALUES ('5', '1', 'system_member_register', '', '会员注册成功后的动作', '1', '1490885108', '1490885108');

-- -----------------------------
-- Table structure for `hisi_admin_hook_plugins`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_hook_plugins`;
CREATE TABLE `hisi_admin_hook_plugins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(32) NOT NULL COMMENT '钩子id',
  `plugins` varchar(32) NOT NULL COMMENT '插件标识',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 钩子-插件对应表';

-- -----------------------------
-- Records of `hisi_admin_hook_plugins`
-- -----------------------------
INSERT INTO `hisi_admin_hook_plugins` VALUES ('1', 'system_admin_index', 'hisiphp', '1510063011', '1510063011', '0', '1');

-- -----------------------------
-- Table structure for `hisi_admin_language`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_language`;
CREATE TABLE `hisi_admin_language` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '语言包名称',
  `code` varchar(20) NOT NULL DEFAULT '' COMMENT '编码',
  `locale` varchar(255) NOT NULL DEFAULT '' COMMENT '本地浏览器语言编码',
  `icon` varchar(30) NOT NULL DEFAULT '' COMMENT '图标',
  `pack` varchar(100) NOT NULL DEFAULT '' COMMENT '上传的语言包',
  `sort` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 语言包';

-- -----------------------------
-- Records of `hisi_admin_language`
-- -----------------------------
INSERT INTO `hisi_admin_language` VALUES ('1', '简体中文', 'zh-cn', 'zh-CN,zh-CN.UTF-8,zh-cn', '', '1', '1', '1');

-- -----------------------------
-- Table structure for `hisi_admin_log`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_log`;
CREATE TABLE `hisi_admin_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT '',
  `url` varchar(200) DEFAULT '',
  `param` text,
  `remark` varchar(255) DEFAULT '',
  `count` int(10) unsigned NOT NULL DEFAULT '1',
  `ip` varchar(128) DEFAULT '',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 操作日志';

-- -----------------------------
-- Records of `hisi_admin_log`
-- -----------------------------
INSERT INTO `hisi_admin_log` VALUES ('1', '1', '后台首页', 'admin/index/index', '[]', '浏览数据', '88', '113.65.228.131', '1556013081', '1560475826');
INSERT INTO `hisi_admin_log` VALUES ('2', '1', '系统设置', 'admin/system/index', '[]', '浏览数据', '14', '113.65.228.131', '1556013091', '1560480750');
INSERT INTO `hisi_admin_log` VALUES ('3', '1', '上传配置', 'admin/system/index', '{\"group\":\"upload\"}', '浏览数据', '1', '127.0.0.1', '1556013098', '1556013098');
INSERT INTO `hisi_admin_log` VALUES ('4', '1', '配置管理', 'admin/config/index', '{\"page\":\"1\",\"limit\":\"20\"}', '浏览数据', '28', '113.65.228.131', '1556013101', '1560480754');
INSERT INTO `hisi_admin_log` VALUES ('5', '1', '系统菜单', 'admin/menu/index', '[]', '浏览数据', '136', '113.65.228.131', '1556013101', '1560480755');
INSERT INTO `hisi_admin_log` VALUES ('6', '1', '系统管理员', 'admin/user/index', '{\"page\":\"1\",\"limit\":\"20\"}', '浏览数据', '90', '113.65.228.131', '1556013102', '1560480757');
INSERT INTO `hisi_admin_log` VALUES ('7', '1', '模块管理', 'admin/module/index', '{\"status\":\"2\"}', '浏览数据', '4', '127.0.0.1', '1556013787', '1556013797');
INSERT INTO `hisi_admin_log` VALUES ('8', '1', '导入模块', 'admin/module/import', '[]', '浏览数据', '1', '127.0.0.1', '1556013794', '1556013794');
INSERT INTO `hisi_admin_log` VALUES ('9', '1', '设计模块', 'admin/module/design', '[]', '浏览数据', '1', '127.0.0.1', '1556013795', '1556013795');
INSERT INTO `hisi_admin_log` VALUES ('10', '1', '系统日志', 'admin/log/index', '{\"page\":\"1\",\"limit\":\"20\"}', '浏览数据', '12', '113.65.228.131', '1556013809', '1560480760');
INSERT INTO `hisi_admin_log` VALUES ('11', '1', '添加菜单', 'admin/menu/add', '{\"pid\":\"1\",\"mod\":\"admin\"}', '浏览数据', '39', '113.65.228.131', '1556093842', '1560476657');
INSERT INTO `hisi_admin_log` VALUES ('12', '1', '添加菜单', 'admin/menu/add', '{\"pid\":\"219\",\"title\":\"\\u8ba2\\u5355\\u5217\\u8868\",\"icon\":\"\",\"url\":\"admin\\/order\\/index\",\"param\":\"\",\"status\":\"1\",\"system\":\"0\",\"nav\":\"1\",\"id\":\"\",\"module\":\"admin\"}', '保存数据', '19', '113.65.228.131', '1556093874', '1560476690');
INSERT INTO `hisi_admin_log` VALUES ('13', '1', '布局切换', 'admin/user/iframe', '[]', '浏览数据', '2', '127.0.0.1', '1556093891', '1558504564');
INSERT INTO `hisi_admin_log` VALUES ('14', '1', '后台首页', 'admin/index/welcome', '[]', '浏览数据', '35', '127.0.0.1', '1556093895', '1558504562');
INSERT INTO `hisi_admin_log` VALUES ('15', '1', '编辑产品标题', 'admin/goods/index', '{\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '50', '127.0.0.1', '1556093925', '1558332150');
INSERT INTO `hisi_admin_log` VALUES ('16', '1', '编辑', 'admin/goods/edit', '{\"id\":\"1\"}', '浏览数据', '25', '127.0.0.1', '1556094094', '1556094652');
INSERT INTO `hisi_admin_log` VALUES ('17', '1', '编辑', 'admin/goods/edit', '{\"qq\":\"1277275939\",\"phone\":\"13144132521\",\"address\":\"\\u5e7f\\u5dde\\u5e02\\u5929\\u6cb3\\u533a\",\"id\":\"1\"}', '保存数据', '6', '127.0.0.1', '1556094627', '1556095025');
INSERT INTO `hisi_admin_log` VALUES ('18', '1', '编辑QQ/地址/电话', 'admin/goods/common_config_edit', '[]', '浏览数据', '18', '127.0.0.1', '1556094710', '1558332152');
INSERT INTO `hisi_admin_log` VALUES ('19', '1', '编辑QQ/地址/电话', 'admin/goods/common_config_edit', '{\"qq\":\"443235363\",\"phone\":\"15802011993\",\"address\":\"\\u5e7f\\u4e1c\\u7701\\u5e7f\\u5dde\\u5e02\\u5929\\u6cb3\\u533a\\u9ec4\\u6751\\u798f\\u5143\\u5357\\u8def4\\u53f71325\",\"id\":\"1\"}', '保存数据', '5', '113.105.5.26', '1556095076', '1557561401');
INSERT INTO `hisi_admin_log` VALUES ('20', '1', '数据库配置', 'admin/system/index', '{\"group\":\"databases\"}', '浏览数据', '1', '119.131.153.67', '1557296500', '1557296500');
INSERT INTO `hisi_admin_log` VALUES ('21', '1', '设置主题', 'admin/user/setTheme', '{\"theme\":\"0\"}', '浏览数据', '1', '127.0.0.1', '1558331616', '1558331616');
INSERT INTO `hisi_admin_log` VALUES ('22', '1', '修改菜单', 'admin/menu/edit', '{\"id\":\"209\",\"mod\":\"admin\"}', '浏览数据', '30', '113.65.228.131', '1558331971', '1560475847');
INSERT INTO `hisi_admin_log` VALUES ('23', '1', '修改菜单', 'admin/menu/edit', '{\"pid\":\"210\",\"title\":\"\\u57df\\u540d\\u4fee\\u6539\",\"icon\":\"\",\"url\":\"admin\\/wechat\\/edit\",\"param\":\"\",\"status\":\"1\",\"system\":\"0\",\"nav\":\"1\",\"id\":\"212\",\"module\":\"admin\"}', '保存数据', '13', '127.0.0.1', '1558331983', '1559111892');
INSERT INTO `hisi_admin_log` VALUES ('24', '1', '删除菜单', 'admin/menu/del', '{\"ids\":\"212\"}', '浏览数据', '6', '113.65.228.245', '1558332177', '1560231697');
INSERT INTO `hisi_admin_log` VALUES ('25', '1', '穿山甲管理', 'admin/pangolin/index', '[]', '浏览数据', '3', '127.0.0.1', '1558502728', '1558503195');
INSERT INTO `hisi_admin_log` VALUES ('26', '1', '穿山甲管理', 'admin/shield/index', '{\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '148', '113.65.228.131', '1558503322', '1560388115');
INSERT INTO `hisi_admin_log` VALUES ('27', '1', '添加快捷菜单', 'admin/menu/quick', '{\"id\":\"206\"}', '浏览数据', '1', '127.0.0.1', '1558504559', '1558504559');
INSERT INTO `hisi_admin_log` VALUES ('28', '1', '屏蔽详情', 'admin/shield/edit', '{\"id\":\"1\"}', '浏览数据', '136', '113.65.228.245', '1558506218', '1560221318');
INSERT INTO `hisi_admin_log` VALUES ('29', '1', '微信管理', 'admin/wechat/index', '{\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '165', '127.0.0.1', '1558698285', '1559015018');
INSERT INTO `hisi_admin_log` VALUES ('30', '1', '微信添加', 'admin/wechat/add', '[]', '浏览数据', '5', '127.0.0.1', '1558699697', '1559014142');
INSERT INTO `hisi_admin_log` VALUES ('31', '1', '微信修改', 'admin/wechat/edit', '{\"id\":\"1\"}', '浏览数据', '10', '127.0.0.1', '1559007236', '1559014075');
INSERT INTO `hisi_admin_log` VALUES ('32', '1', '微信号管理', 'admin/wechat/wechat', '{\"urlid\":\"1\",\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '69', '127.0.0.1', '1559009294', '1559021615');
INSERT INTO `hisi_admin_log` VALUES ('33', '1', '域名管理', 'admin/wechat/index', '{\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '2', '127.0.0.1', '1559021595', '1559021596');
INSERT INTO `hisi_admin_log` VALUES ('34', '1', '域名管理', 'admin/domainname/index', '{\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '168', '113.65.228.131', '1559022195', '1560480195');
INSERT INTO `hisi_admin_log` VALUES ('35', '1', '微信号管理', 'admin/domainname/wechat', '{\"urlid\":\"2\",\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '121', '113.65.228.245', '1559022250', '1560302448');
INSERT INTO `hisi_admin_log` VALUES ('36', '1', '微信添加', 'admin/domainname/wechatadd', '{\"urlid\":\"1\"}', '浏览数据', '54', '113.65.228.245', '1559022418', '1560224400');
INSERT INTO `hisi_admin_log` VALUES ('37', '1', '附件上传', 'admin/annex/upload', '{\"thumb\":\"no\",\"water\":\"no\",\"group\":\"iamge\"}', '保存数据', '7', '113.65.228.245', '1559022634', '1560228168');
INSERT INTO `hisi_admin_log` VALUES ('38', '1', '微信添加', 'admin/domainname/wechatadd', '{\"name\":\"123456\",\"url\":\"1.jpg\",\"id\":\"1\",\"urlid\":\"1\"}', '保存数据', '52', '127.0.0.1', '1559022858', '1559112748');
INSERT INTO `hisi_admin_log` VALUES ('39', '1', '微信修改', 'admin/domainname/wechatedit', '{\"id\":\"1\"}', '浏览数据', '51', '113.65.228.245', '1559112032', '1560229206');
INSERT INTO `hisi_admin_log` VALUES ('40', '1', '微信修改', 'admin/domainname/wechatedit', '{\"name\":\"111111\",\"url\":\"1.jpg\",\"id\":\"1\",\"urlid\":\"1\"}', '保存数据', '27', '113.65.228.245', '1559112774', '1560229202');
INSERT INTO `hisi_admin_log` VALUES ('41', '1', '微信号删除', 'admin/domainname/wechatdel', '{\"id\":\"5\"}', '浏览数据', '1', '127.0.0.1', '1559115346', '1559115346');
INSERT INTO `hisi_admin_log` VALUES ('42', '1', '微信号删除', 'admin/domainname/wechatdel', '{\"id\":[\"3\",\"4\"]}', '保存数据', '1', '127.0.0.1', '1559115378', '1559115378');
INSERT INTO `hisi_admin_log` VALUES ('43', '1', '管理员角色', 'admin/user/role', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '34', '113.65.228.131', '1560224502', '1560318157');
INSERT INTO `hisi_admin_log` VALUES ('44', '1', '添加角色', 'admin/user/addrole', '[]', '浏览数据', '2', '113.65.228.245', '1560224503', '1560224551');
INSERT INTO `hisi_admin_log` VALUES ('45', '1', '添加角色', 'admin/user/addrole', '{\"name\":\"\\u5fae\\u4fe1\\u53f7\\u7ba1\\u7406\",\"intro\":\"\\u5fae\\u4fe1\\u53f7\\u7ba1\\u7406\",\"status\":\"1\",\"auth\":{\"0\":\"1\",\"4\":\"209\",\"5\":\"210\",\"9\":\"215\",\"10\":\"216\",\"11\":\"217\"},\"id\":\"\"}', '保存数据', '2', '113.65.228.245', '1560224527', '1560224547');
INSERT INTO `hisi_admin_log` VALUES ('46', '1', '添加管理员', 'admin/user/adduser', '[]', '浏览数据', '4', '113.65.228.245', '1560224574', '1560225988');
INSERT INTO `hisi_admin_log` VALUES ('47', '1', '添加管理员', 'admin/user/adduser', '{\"role_id\":\"3\",\"username\":\"user02\",\"nick\":\"user02\",\"password\":\"123456\",\"password_confirm\":\"123456\",\"email\":\"\",\"mobile\":\"\",\"status\":\"1\",\"id\":\"\"}', '保存数据', '3', '113.65.228.245', '1560224589', '1560225984');
INSERT INTO `hisi_admin_log` VALUES ('48', '1', '修改角色', 'admin/user/editrole', '{\"id\":\"3\"}', '浏览数据', '21', '113.65.228.131', '1560224603', '1560318176');
INSERT INTO `hisi_admin_log` VALUES ('49', '1', '修改角色', 'admin/user/editrole', '{\"name\":\"\\u5fae\\u4fe1\\u53f7\\u7ba1\\u7406\",\"intro\":\"\\u5fae\\u4fe1\\u53f7\\u7ba1\\u7406\",\"status\":\"1\",\"auth\":{\"0\":\"1\",\"1\":\"4\",\"3\":\"24\",\"10\":\"209\",\"11\":\"210\",\"13\":\"213\",\"14\":\"215\",\"15\":\"216\",\"16\":\"217\",\"17\":\"218\",\"18\":\"2\",\"19\":\"6\",\"45\":\"14\",\"50\":\"41\"},\"id\":\"3\"}', '保存数据', '9', '113.65.228.131', '1560224630', '1560318033');
INSERT INTO `hisi_admin_log` VALUES ('50', '1', '修改管理员', 'admin/user/edituser', '{\"id\":\"2\"}', '浏览数据', '9', '113.65.228.131', '1560224817', '1560318142');
INSERT INTO `hisi_admin_log` VALUES ('51', '1', '状态设置', 'admin/menu/status', '{\"val\":\"0\",\"table\":\"admin_menu\",\"ids\":\"4\"}', '浏览数据', '3', '113.65.228.131', '1560224876', '1560318296');
INSERT INTO `hisi_admin_log` VALUES ('52', '1', '修改管理员', 'admin/user/edituser', '{\"role_id\":\"3\",\"username\":\"user01\",\"nick\":\"user01\",\"password\":\"\",\"password_confirm\":\"\",\"email\":\"\",\"mobile\":\"\",\"status\":\"1\",\"auth\":{\"0\":\"1\",\"1\":\"4\",\"3\":\"24\",\"10\":\"209\",\"11\":\"210\",\"13\":\"213\",\"14\":\"215\",\"15\":\"216\",\"16\":\"217\",\"17\":\"218\",\"18\":\"2\",\"19\":\"6\",\"45\":\"14\",\"50\":\"41\"},\"id\":\"2\"}', '保存数据', '3', '113.65.228.131', '1560224990', '1560317982');
INSERT INTO `hisi_admin_log` VALUES ('53', '1', '数据库管理', 'admin/database/index', '[]', '浏览数据', '3', '113.65.228.131', '1560226599', '1560480764');
INSERT INTO `hisi_admin_log` VALUES ('54', '1', '会员等级', 'admin/member/level', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '6', '113.65.228.245', '1560226602', '1560302348');
INSERT INTO `hisi_admin_log` VALUES ('55', '1', '清空缓存', 'admin/index/clear', '[]', '浏览数据', '13', '113.65.228.131', '1560226634', '1560476651');
INSERT INTO `hisi_admin_log` VALUES ('56', '2', '后台首页', 'admin/index/index', '[]', '浏览数据', '6', '113.65.228.131', '1560226837', '1560318196');
INSERT INTO `hisi_admin_log` VALUES ('57', '2', '域名管理', 'admin/domainname/index', '{\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '86', '113.65.228.131', '1560226845', '1560318199');
INSERT INTO `hisi_admin_log` VALUES ('58', '2', '个人信息设置', 'admin/user/info', '[]', '浏览数据', '1', '113.65.228.245', '1560226854', '1560226854');
INSERT INTO `hisi_admin_log` VALUES ('59', '2', '微信号管理', 'admin/domainname/wechat', '{\"urlid\":\"1\",\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '10', '113.65.228.245', '1560229220', '1560236000');
INSERT INTO `hisi_admin_log` VALUES ('60', '2', '微信修改', 'admin/domainname/wechatedit', '{\"id\":\"2\"}', '浏览数据', '1', '113.65.228.245', '1560229414', '1560229414');
INSERT INTO `hisi_admin_log` VALUES ('61', '1', '修改配置', 'admin/config/edit', '{\"id\":\"47\"}', '浏览数据', '1', '113.65.228.245', '1560231794', '1560231794');
INSERT INTO `hisi_admin_log` VALUES ('62', '1', '域名修改', 'admin/domainname/edit', '{\"id\":\"2\"}', '浏览数据', '15', '113.65.228.131', '1560231889', '1560387937');
INSERT INTO `hisi_admin_log` VALUES ('63', '3', '后台首页', 'admin/index/index', '[]', '浏览数据', '2', '113.65.228.245', '1560235958', '1560236011');
INSERT INTO `hisi_admin_log` VALUES ('64', '3', '域名管理', 'admin/domainname/index', '{\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '14', '113.65.228.245', '1560235960', '1560236869');
INSERT INTO `hisi_admin_log` VALUES ('65', '3', '微信号管理', 'admin/domainname/wechat', '{\"urlid\":\"2\",\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '2', '113.65.228.245', '1560236870', '1560236871');
INSERT INTO `hisi_admin_log` VALUES ('66', '3', '微信修改', 'admin/domainname/wechatedit', '{\"id\":\"6\"}', '浏览数据', '2', '113.65.228.245', '1560236873', '1560236879');
INSERT INTO `hisi_admin_log` VALUES ('67', '3', '微信修改', 'admin/domainname/wechatedit', '{\"name\":\"jfweix2991\",\"url\":\"\",\"id\":\"6\",\"urlid\":\"2\"}', '保存数据', '1', '113.65.228.245', '1560236876', '1560236876');
INSERT INTO `hisi_admin_log` VALUES ('68', '1', '个人信息设置', 'admin/user/info', '[]', '浏览数据', '2', '113.65.228.245', '1560302310', '1560302328');
INSERT INTO `hisi_admin_log` VALUES ('69', '1', '个人信息设置', 'admin/user/info', '{\"username\":\"admin\",\"nick\":\"\\u8d85\\u7ea7\\u7ba1\\u7406\\u5458\",\"password\":\"zd123456\",\"password_confirm\":\"zd123456\",\"email\":\"\",\"mobile\":\"\",\"id\":\"\"}', '保存数据', '1', '113.65.228.245', '1560302324', '1560302324');
INSERT INTO `hisi_admin_log` VALUES ('70', '1', '会员列表', 'admin/member/index', '[]', '浏览数据', '1', '113.65.228.245', '1560302343', '1560302343');
INSERT INTO `hisi_admin_log` VALUES ('71', '1', '基础配置', 'admin/system/index', '{\"id\":{\"site_status\":\"1\",\"site_domain\":\"\",\"wap_site_status\":\"1\",\"wap_domain\":\"ms.hisiphp.cn\",\"site_name\":\"\\u84dd\\u9f0e\\u7f51\\u7edc\",\"site_logo\":\"\",\"site_favicon\":\"\",\"site_title\":\"HisiPHP\\u5e94\\u7528\\u5e02\\u573a\",\"site_keywords\":\"hisiphp,hisiphp\\u6846\\u67b6,php\\u5f00\\u6e90\\u6846\\u67b6\",\"site_description\":\"\",\"site_icp\":\"\",\"site_statis\":\"&lt;script&gt;alert(\'a\')&lt;\\/script&gt;\"},\"type\":{\"site_status\":\"switch\",\"site_domain\":\"input\",\"wap_site_status\":\"switch\",\"wap_domain\":\"input\",\"site_name\":\"input\",\"site_logo\":\"image\",\"site_favicon\":\"image\",\"site_title\":\"input\",\"site_keywords\":\"input\",\"site_description\":\"textarea\",\"site_icp\":\"input\",\"site_statis\":\"textarea\"},\"group\":\"base\"}', '保存数据', '1', '113.65.228.245', '1560302381', '1560302381');
INSERT INTO `hisi_admin_log` VALUES ('72', '1', '基础配置', 'admin/system/index', '{\"group\":\"base\"}', '浏览数据', '1', '113.65.228.245', '1560302384', '1560302384');
INSERT INTO `hisi_admin_log` VALUES ('73', '1', '域名修改', 'admin/domainname/edit', '{\"title\":\"cx2k.szjssm.cn\",\"url\":\"http:\\/\\/cx2k.szjssm.cn\",\"id\":\"1\"}', '保存数据', '2', '113.65.228.131', '1560310727', '1560310739');
INSERT INTO `hisi_admin_log` VALUES ('74', '2', '域名修改', 'admin/domainname/edit', '{\"id\":\"1\"}', '浏览数据', '1', '113.65.228.131', '1560318200', '1560318200');
INSERT INTO `hisi_admin_log` VALUES ('75', '1', '状态设置', 'admin/menu/status', '{\"ids\":{\"1\":\"4\"},\"sort\":{\"1\":\"0\",\"3\":\"2\",\"5\":\"100\",\"7\":\"100\",\"9\":\"100\",\"11\":\"100\",\"14\":\"0\",\"16\":\"0\",\"18\":\"0\",\"20\":\"0\",\"22\":\"0\",\"24\":\"0\",\"25\":\"0\",\"26\":\"0\",\"27\":\"0\",\"28\":\"0\",\"29\":\"0\"},\"status\":\"1\",\"table\":\"admin_menu\",\"val\":\"0\"}', '保存数据', '1', '113.65.228.131', '1560318327', '1560318327');
INSERT INTO `hisi_admin_log` VALUES ('76', '1', '订单管理', 'admin/order/index', '{\"search\":\"\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '67', '113.65.228.131', '1560476696', '1560480470');
INSERT INTO `hisi_admin_log` VALUES ('77', '1', '备份数据库', 'admin/database/export', '{\"id\":[\"hisi_admin_annex\",\"hisi_admin_annex_group\",\"hisi_admin_config\",\"hisi_admin_hook\",\"hisi_admin_hook_plugins\",\"hisi_admin_language\",\"hisi_admin_log\",\"hisi_admin_member\",\"hisi_admin_member_level\",\"hisi_admin_menu\",\"hisi_admin_menu_lang\",\"hisi_admin_module\",\"hisi_admin_plugins\",\"hisi_admin_role\",\"hisi_admin_user\",\"hisi_common_config\",\"hisi_header1\",\"hisi_order\",\"hisi_shield\",\"hisi_swiper_index\",\"hisi_url\",\"hisi_wechat\"]}', '保存数据', '1', '113.65.228.131', '1560480770', '1560480770');

-- -----------------------------
-- Table structure for `hisi_admin_member`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_member`;
CREATE TABLE `hisi_admin_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员等级ID',
  `nick` varchar(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `username` varchar(30) NOT NULL DEFAULT '' COMMENT '用户名',
  `mobile` bigint(11) unsigned NOT NULL DEFAULT '0' COMMENT '手机号',
  `email` varchar(50) NOT NULL DEFAULT '' COMMENT '邮箱',
  `password` varchar(128) NOT NULL COMMENT '密码',
  `money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '可用金额',
  `frozen_money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '冻结金额',
  `income` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '收入统计',
  `expend` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '开支统计',
  `exper` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '经验值',
  `integral` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '积分',
  `frozen_integral` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '冻结积分',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '性别(1男，0女)',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `last_login_ip` varchar(128) NOT NULL DEFAULT '' COMMENT '最后登陆IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登陆时间',
  `login_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登陆次数',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '到期时间(0永久)',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态(0禁用，1正常)',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1000001 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 会员表';

-- -----------------------------
-- Records of `hisi_admin_member`
-- -----------------------------
INSERT INTO `hisi_admin_member` VALUES ('1000000', '1', '', 'test', '0', '', '$2y$10$WC0mMyErW1u1JCLXDCbTIuagCceC/kKpjzvCf.cxrVKaxsrZLXrGe', '0.00', '0.00', '0.00', '0.00', '0', '0', '0', '1', '', '', '0', '0', '0', '1', '1493274686');

-- -----------------------------
-- Table structure for `hisi_admin_member_level`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_member_level`;
CREATE TABLE `hisi_admin_member_level` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL COMMENT '等级名称',
  `min_exper` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最小经验值',
  `max_exper` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最大经验值',
  `discount` int(2) unsigned NOT NULL DEFAULT '100' COMMENT '折扣率(%)',
  `intro` varchar(255) NOT NULL COMMENT '等级简介',
  `default` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '默认等级',
  `expire` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员有效期(天)',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 会员等级';

-- -----------------------------
-- Records of `hisi_admin_member_level`
-- -----------------------------
INSERT INTO `hisi_admin_member_level` VALUES ('1', '注册会员', '0', '0', '100', '', '1', '0', '1', '0', '1491966814');

-- -----------------------------
-- Table structure for `hisi_admin_menu`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_menu`;
CREATE TABLE `hisi_admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID(快捷菜单专用)',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `module` varchar(20) NOT NULL COMMENT '模块名或插件名，插件名格式:plugins.插件名',
  `title` varchar(20) NOT NULL COMMENT '菜单标题',
  `icon` varchar(80) NOT NULL DEFAULT 'aicon ai-shezhi' COMMENT '菜单图标',
  `url` varchar(200) NOT NULL COMMENT '链接地址(模块/控制器/方法)',
  `param` varchar(200) NOT NULL DEFAULT '' COMMENT '扩展参数',
  `target` varchar(20) NOT NULL DEFAULT '_self' COMMENT '打开方式(_blank,_self)',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `debug` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '开发模式可见',
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统菜单，系统菜单不可删除',
  `nav` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否为菜单显示，1显示0不显示',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态1显示，0隐藏',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 管理菜单';

-- -----------------------------
-- Records of `hisi_admin_menu`
-- -----------------------------
INSERT INTO `hisi_admin_menu` VALUES ('1', '0', '0', 'admin', '首页', '', 'admin/index', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('2', '0', '0', 'admin', '系统', '', 'admin/system', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('3', '0', '0', 'admin', '插件', 'aicon ai-shezhi', 'admin/plugins', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('4', '0', '1', 'admin', '快捷菜单', 'aicon ai-caidan', 'admin/quick', '', '_self', '0', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('5', '0', '3', 'admin', '插件列表', 'aicon ai-mokuaiguanli', 'admin/plugins', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('6', '0', '2', 'admin', '系统功能', 'aicon ai-gongneng', 'admin/system', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('7', '0', '2', 'admin', '会员管理', 'aicon ai-huiyuanliebiao', 'admin/member', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('8', '0', '2', 'admin', '系统扩展', 'aicon ai-shezhi', 'admin/extend', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('9', '0', '2', 'admin', '预留占位', '', '', '', '_self', '4', '1', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('10', '0', '6', 'admin', '系统设置', 'aicon ai-icon01', 'admin/system/index', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('11', '0', '6', 'admin', '配置管理', 'aicon ai-peizhiguanli', 'admin/config/index', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('12', '0', '6', 'admin', '系统菜单', 'aicon ai-systemmenu', 'admin/menu/index', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('13', '0', '6', 'admin', '管理员角色', '', 'admin/user/role', '', '_self', '4', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('14', '0', '6', 'admin', '系统管理员', 'aicon ai-tubiao05', 'admin/user/index', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('15', '0', '6', 'admin', '系统日志', 'aicon ai-xitongrizhi-tiaoshi', 'admin/log/index', '', '_self', '6', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('16', '0', '6', 'admin', '附件管理', '', 'admin/annex/index', '', '_self', '7', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('17', '0', '8', 'admin', '模块管理', 'aicon ai-mokuaiguanli1', 'admin/module/index', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('18', '0', '8', 'admin', '插件管理', 'aicon ai-chajianguanli', 'admin/plugins/index', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('19', '0', '8', 'admin', '钩子管理', 'aicon ai-icon-test', 'admin/hook/index', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('20', '0', '7', 'admin', '会员等级', 'aicon ai-huiyuandengji', 'admin/member/level', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('21', '0', '7', 'admin', '会员列表', 'aicon ai-huiyuanliebiao', 'admin/member/index', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('22', '0', '9', 'admin', '预留占位', '', '', '', '_self', '1', '1', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('23', '0', '9', 'admin', '预留占位', '', '', '', '_self', '2', '1', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('24', '0', '4', 'admin', '后台首页', '', 'admin/index/index', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('25', '0', '4', 'admin', '清空缓存', '', 'admin/index/clear', '', '_self', '2', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('26', '0', '12', 'admin', '添加菜单', '', 'admin/menu/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('27', '0', '12', 'admin', '修改菜单', '', 'admin/menu/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('28', '0', '12', 'admin', '删除菜单', '', 'admin/menu/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('29', '0', '12', 'admin', '状态设置', '', 'admin/menu/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('30', '0', '12', 'admin', '排序设置', '', 'admin/menu/sort', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('31', '0', '12', 'admin', '添加快捷菜单', '', 'admin/menu/quick', '', '_self', '6', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('32', '0', '12', 'admin', '导出菜单', '', 'admin/menu/export', '', '_self', '7', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('33', '0', '13', 'admin', '添加角色', '', 'admin/user/addrole', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('34', '0', '13', 'admin', '修改角色', '', 'admin/user/editrole', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('35', '0', '13', 'admin', '删除角色', '', 'admin/user/delrole', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('36', '0', '13', 'admin', '状态设置', '', 'admin/user/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('37', '0', '14', 'admin', '添加管理员', '', 'admin/user/adduser', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('38', '0', '14', 'admin', '修改管理员', '', 'admin/user/edituser', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('39', '0', '14', 'admin', '删除管理员', '', 'admin/user/deluser', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('40', '0', '14', 'admin', '状态设置', '', 'admin/user/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('41', '0', '14', 'admin', '个人信息设置', '', 'admin/user/info', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('42', '0', '18', 'admin', '安装插件', '', 'admin/plugins/install', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('43', '0', '18', 'admin', '卸载插件', '', 'admin/plugins/uninstall', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('44', '0', '18', 'admin', '删除插件', '', 'admin/plugins/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('45', '0', '18', 'admin', '状态设置', '', 'admin/plugins/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('46', '0', '18', 'admin', '设计插件', '', 'admin/plugins/design', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('47', '0', '18', 'admin', '运行插件', '', 'admin/plugins/run', '', '_self', '6', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('48', '0', '18', 'admin', '更新插件', '', 'admin/plugins/update', '', '_self', '7', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('49', '0', '18', 'admin', '插件配置', '', 'admin/plugins/setting', '', '_self', '8', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('50', '0', '19', 'admin', '添加钩子', '', 'admin/hook/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('51', '0', '19', 'admin', '修改钩子', '', 'admin/hook/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('52', '0', '19', 'admin', '删除钩子', '', 'admin/hook/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('53', '0', '19', 'admin', '状态设置', '', 'admin/hook/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('54', '0', '19', 'admin', '插件排序', '', 'admin/hook/sort', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('55', '0', '11', 'admin', '添加配置', '', 'admin/config/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('56', '0', '11', 'admin', '修改配置', '', 'admin/config/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('57', '0', '11', 'admin', '删除配置', '', 'admin/config/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('58', '0', '11', 'admin', '状态设置', '', 'admin/config/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('59', '0', '11', 'admin', '排序设置', '', 'admin/config/sort', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('60', '0', '10', 'admin', '基础配置', '', 'admin/system/index', 'group=base', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('61', '0', '10', 'admin', '系统配置', '', 'admin/system/index', 'group=sys', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('62', '0', '10', 'admin', '上传配置', '', 'admin/system/index', 'group=upload', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('63', '0', '10', 'admin', '开发配置', '', 'admin/system/index', 'group=develop', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('64', '0', '17', 'admin', '设计模块', '', 'admin/module/design', '', '_self', '6', '1', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('65', '0', '17', 'admin', '安装模块', '', 'admin/module/install', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('66', '0', '17', 'admin', '卸载模块', '', 'admin/module/uninstall', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('67', '0', '17', 'admin', '状态设置', '', 'admin/module/status', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('68', '0', '17', 'admin', '设置默认模块', '', 'admin/module/setdefault', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('69', '0', '17', 'admin', '删除模块', '', 'admin/module/del', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('70', '0', '21', 'admin', '添加会员', '', 'admin/member/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('71', '0', '21', 'admin', '修改会员', '', 'admin/member/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('72', '0', '21', 'admin', '删除会员', '', 'admin/member/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('73', '0', '21', 'admin', '状态设置', '', 'admin/member/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('74', '0', '21', 'admin', '[弹窗]会员选择', '', 'admin/member/pop', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('75', '0', '20', 'admin', '添加会员等级', '', 'admin/member/addlevel', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('76', '0', '20', 'admin', '修改会员等级', '', 'admin/member/editlevel', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('77', '0', '20', 'admin', '删除会员等级', '', 'admin/member/dellevel', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('78', '0', '16', 'admin', '附件上传', '', 'admin/annex/upload', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('79', '0', '16', 'admin', '删除附件', '', 'admin/annex/del', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('80', '0', '8', 'admin', '在线升级', 'aicon ai-iconfontshengji', 'admin/upgrade/index', '', '_self', '4', '0', '1', '1', '1', '1491352728');
INSERT INTO `hisi_admin_menu` VALUES ('81', '0', '80', 'admin', '获取升级列表', '', 'admin/upgrade/lists', '', '_self', '0', '0', '1', '1', '1', '1491353504');
INSERT INTO `hisi_admin_menu` VALUES ('82', '0', '80', 'admin', '安装升级包', '', 'admin/upgrade/install', '', '_self', '0', '0', '1', '1', '1', '1491353568');
INSERT INTO `hisi_admin_menu` VALUES ('83', '0', '80', 'admin', '下载升级包', '', 'admin/upgrade/download', '', '_self', '0', '0', '1', '1', '1', '1491395830');
INSERT INTO `hisi_admin_menu` VALUES ('84', '0', '6', 'admin', '数据库管理', 'aicon ai-shujukuguanli', 'admin/database/index', '', '_self', '8', '0', '1', '1', '1', '1491461136');
INSERT INTO `hisi_admin_menu` VALUES ('85', '0', '84', 'admin', '备份数据库', '', 'admin/database/export', '', '_self', '0', '0', '1', '1', '1', '1491461250');
INSERT INTO `hisi_admin_menu` VALUES ('86', '0', '84', 'admin', '恢复数据库', '', 'admin/database/import', '', '_self', '0', '0', '1', '1', '1', '1491461315');
INSERT INTO `hisi_admin_menu` VALUES ('87', '0', '84', 'admin', '优化数据库', '', 'admin/database/optimize', '', '_self', '0', '0', '1', '1', '1', '1491467000');
INSERT INTO `hisi_admin_menu` VALUES ('88', '0', '84', 'admin', '删除备份', '', 'admin/database/del', '', '_self', '0', '0', '1', '1', '1', '1491467058');
INSERT INTO `hisi_admin_menu` VALUES ('89', '0', '84', 'admin', '修复数据库', '', 'admin/database/repair', '', '_self', '0', '0', '1', '1', '1', '1491880879');
INSERT INTO `hisi_admin_menu` VALUES ('90', '0', '21', 'admin', '设置默认等级', '', 'admin/member/setdefault', '', '_self', '0', '0', '1', '1', '1', '1491966585');
INSERT INTO `hisi_admin_menu` VALUES ('91', '0', '10', 'admin', '数据库配置', '', 'admin/system/index', 'group=databases', '_self', '5', '0', '1', '0', '1', '1492072213');
INSERT INTO `hisi_admin_menu` VALUES ('92', '0', '17', 'admin', '模块打包', '', 'admin/module/package', '', '_self', '7', '0', '1', '1', '1', '1492134693');
INSERT INTO `hisi_admin_menu` VALUES ('93', '0', '18', 'admin', '插件打包', '', 'admin/plugins/package', '', '_self', '0', '0', '1', '1', '1', '1492134743');
INSERT INTO `hisi_admin_menu` VALUES ('94', '0', '17', 'admin', '主题管理', '', 'admin/module/theme', '', '_self', '8', '0', '1', '1', '1', '1492433470');
INSERT INTO `hisi_admin_menu` VALUES ('95', '0', '17', 'admin', '设置默认主题', '', 'admin/module/setdefaulttheme', '', '_self', '9', '0', '1', '1', '1', '1492433618');
INSERT INTO `hisi_admin_menu` VALUES ('96', '0', '17', 'admin', '删除主题', '', 'admin/module/deltheme', '', '_self', '10', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('97', '0', '6', 'admin', '语言包管理', '', 'admin/language/index', '', '_self', '11', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('98', '0', '97', 'admin', '添加语言包', '', 'admin/language/add', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('99', '0', '97', 'admin', '修改语言包', '', 'admin/language/edit', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('100', '0', '97', 'admin', '删除语言包', '', 'admin/language/del', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('101', '0', '97', 'admin', '排序设置', '', 'admin/language/sort', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('102', '0', '97', 'admin', '状态设置', '', 'admin/language/status', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('103', '0', '16', 'admin', '收藏夹图标上传', '', 'admin/annex/favicon', '', '_self', '3', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('104', '0', '17', 'admin', '导入模块', '', 'admin/module/import', '', '_self', '11', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('105', '0', '4', 'admin', '后台首页', '', 'admin/index/welcome', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('106', '0', '4', 'admin', '布局切换', '', 'admin/user/iframe', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('107', '0', '15', 'admin', '删除日志', '', 'admin/log/del', 'table=admin_log', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('108', '0', '15', 'admin', '清空日志', '', 'admin/log/clear', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('109', '0', '17', 'admin', '编辑模块', '', 'admin/module/edit', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('110', '0', '17', 'admin', '模块图标上传', '', 'admin/module/icon', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('111', '0', '18', 'admin', '导入插件', '', 'admin/plugins/import', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('112', '0', '19', 'admin', '钩子插件状态', '', 'admin/hook/hookPluginsStatus', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('113', '0', '4', 'admin', '设置主题', '', 'admin/user/setTheme', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('114', '0', '8', 'admin', '应用市场', 'aicon ai-app-store', 'admin/store/index', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('115', '0', '114', 'admin', '安装应用', '', 'admin/store/install', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('116', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('117', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('118', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('119', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('120', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('121', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('122', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('123', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('124', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('125', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('126', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('127', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('128', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('129', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('130', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('131', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('132', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('133', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('134', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('135', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('136', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('137', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('138', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('139', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('140', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('141', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('142', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('143', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('144', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('145', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('146', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('147', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('148', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('149', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('150', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('151', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('152', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('153', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('154', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('155', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('156', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('157', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('158', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('159', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('160', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('161', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('162', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('163', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('164', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('165', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('166', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('167', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('168', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('169', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('170', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('171', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('172', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('173', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('174', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('175', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('176', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('177', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('178', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('179', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('180', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('181', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('182', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('183', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('184', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('185', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('186', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('187', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('188', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('189', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('190', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('191', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('192', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('193', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('194', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('195', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('196', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('197', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('198', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('199', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('200', '0', '4', 'admin', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `hisi_admin_menu` VALUES ('205', '0', '1', 'admin', '穿山甲管理', '', 'admin/shield/index', '', '_self', '0', '0', '0', '1', '1', '1558331933');
INSERT INTO `hisi_admin_menu` VALUES ('206', '0', '205', 'admin', '穿山甲列表', '', 'admin/shield/index', '', '_self', '0', '0', '0', '1', '1', '1558332101');
INSERT INTO `hisi_admin_menu` VALUES ('207', '1', '4', 'admin', '穿山甲列表', '', 'admin/shield/index', '', '_self', '0', '0', '0', '1', '1', '1558504559');
INSERT INTO `hisi_admin_menu` VALUES ('208', '0', '206', 'admin', '屏蔽详情', '', 'admin/shield/edit', '', '_self', '0', '0', '0', '1', '1', '1558506213');
INSERT INTO `hisi_admin_menu` VALUES ('209', '0', '1', 'admin', '域名管理', '', 'admin/domainname/index', '', '_self', '0', '0', '0', '1', '1', '1558694739');
INSERT INTO `hisi_admin_menu` VALUES ('210', '0', '209', 'admin', '域名列表', '', 'admin/domainname/index', '', '_self', '0', '0', '0', '1', '1', '1558694807');
INSERT INTO `hisi_admin_menu` VALUES ('211', '0', '210', 'admin', '域名添加', '', 'admin/wechat/add', '', '_self', '0', '0', '0', '1', '1', '1558694959');
INSERT INTO `hisi_admin_menu` VALUES ('213', '0', '210', 'admin', '微信号管理', '', 'admin/domainname/wechat', '', '_self', '0', '0', '0', '1', '1', '1559007360');
INSERT INTO `hisi_admin_menu` VALUES ('214', '0', '213', 'admin', '微信号添加', '', 'admin/wewechat/wechatadd', '', '_self', '0', '0', '0', '1', '1', '1559014214');
INSERT INTO `hisi_admin_menu` VALUES ('215', '0', '210', 'admin', '微信添加', '', 'admin/domainname/wechatadd', '', '_self', '0', '0', '0', '1', '1', '1559022397');
INSERT INTO `hisi_admin_menu` VALUES ('216', '0', '210', 'admin', '微信修改', '', 'admin/domainname/wechatedit', '', '_self', '0', '0', '0', '1', '1', '1559111918');
INSERT INTO `hisi_admin_menu` VALUES ('217', '0', '210', 'admin', '微信号删除', '', 'admin/domainname/wechatdel', '', '_self', '0', '0', '0', '1', '1', '1559115324');
INSERT INTO `hisi_admin_menu` VALUES ('218', '0', '210', 'admin', '域名修改', '', 'admin/domainname/edit', '', '_self', '0', '0', '0', '1', '1', '1560231874');
INSERT INTO `hisi_admin_menu` VALUES ('219', '0', '1', 'admin', '订单管理', '', 'admin/order/index', '', '_self', '0', '0', '0', '1', '1', '1560476214');
INSERT INTO `hisi_admin_menu` VALUES ('220', '0', '219', 'admin', '订单列表', '', 'admin/order/index', '', '_self', '0', '0', '0', '1', '1', '1560476690');

-- -----------------------------
-- Table structure for `hisi_admin_menu_lang`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_menu_lang`;
CREATE TABLE `hisi_admin_menu_lang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(120) NOT NULL DEFAULT '' COMMENT '标题',
  `lang` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '语言包',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- -----------------------------
-- Records of `hisi_admin_menu_lang`
-- -----------------------------
INSERT INTO `hisi_admin_menu_lang` VALUES ('131', '1', '首页', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('132', '2', '系统', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('133', '3', '插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('134', '4', '快捷菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('135', '5', '插件列表', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('136', '6', '系统功能', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('137', '7', '会员管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('138', '8', '系统扩展', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('139', '9', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('140', '10', '系统设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('141', '11', '配置管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('142', '12', '系统菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('143', '13', '管理员角色', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('144', '14', '系统管理员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('145', '15', '系统日志', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('146', '16', '附件管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('147', '17', '模块管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('148', '18', '插件管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('149', '19', '钩子管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('150', '20', '会员等级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('151', '21', '会员列表', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('152', '22', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('153', '23', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('154', '24', '后台首页', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('155', '25', '清空缓存', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('156', '26', '添加菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('157', '27', '修改菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('158', '28', '删除菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('159', '29', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('160', '30', '排序设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('161', '31', '添加快捷菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('162', '32', '导出菜单', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('163', '33', '添加角色', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('164', '34', '修改角色', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('165', '35', '删除角色', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('166', '36', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('167', '37', '添加管理员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('168', '38', '修改管理员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('169', '39', '删除管理员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('170', '40', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('171', '41', '个人信息设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('172', '42', '安装插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('173', '43', '卸载插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('174', '44', '删除插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('175', '45', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('176', '46', '设计插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('177', '47', '运行插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('178', '48', '更新插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('179', '49', '插件配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('180', '50', '添加钩子', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('181', '51', '修改钩子', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('182', '52', '删除钩子', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('183', '53', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('184', '54', '插件排序', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('185', '55', '添加配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('186', '56', '修改配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('187', '57', '删除配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('188', '58', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('189', '59', '排序设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('190', '60', '基础配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('191', '61', '系统配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('192', '62', '上传配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('193', '63', '开发配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('194', '64', '设计模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('195', '65', '安装模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('196', '66', '卸载模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('197', '67', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('198', '68', '设置默认模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('199', '69', '删除模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('200', '70', '添加会员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('201', '71', '修改会员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('202', '72', '删除会员', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('203', '73', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('204', '74', '[弹窗]会员选择', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('205', '75', '添加会员等级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('206', '76', '修改会员等级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('207', '77', '删除会员等级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('208', '78', '附件上传', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('209', '79', '删除附件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('210', '80', '在线升级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('211', '81', '获取升级列表', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('212', '82', '安装升级包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('213', '83', '下载升级包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('214', '84', '数据库管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('215', '85', '备份数据库', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('216', '86', '恢复数据库', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('217', '87', '优化数据库', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('218', '88', '删除备份', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('219', '89', '修复数据库', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('220', '90', '设置默认等级', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('221', '91', '数据库配置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('222', '92', '模块打包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('223', '93', '插件打包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('224', '94', '主题管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('225', '95', '设置默认主题', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('226', '96', '删除主题', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('227', '97', '语言包管理', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('228', '98', '添加语言包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('229', '99', '修改语言包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('230', '100', '删除语言包', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('231', '101', '排序设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('232', '102', '状态设置', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('233', '103', '收藏夹图标上传', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('234', '104', '导入模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('235', '105', '欢迎页面', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('236', '106', '布局切换', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('237', '107', '删除日志', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('238', '108', '清空日志', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('239', '109', '编辑模块', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('240', '110', '模块图标上传', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('241', '111', '导入插件', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('242', '112', '钩子插件状态', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('243', '113', '设置主题', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('244', '114', '应用市场', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('245', '115', '安装应用', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('246', '116', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('247', '117', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('248', '118', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('249', '119', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('250', '120', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('251', '121', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('252', '122', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('253', '123', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('254', '124', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('255', '125', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('256', '126', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('257', '127', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('258', '128', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('259', '129', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('260', '130', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('261', '131', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('262', '132', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('263', '133', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('264', '134', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('265', '135', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('266', '136', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('267', '137', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('268', '138', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('269', '139', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('270', '140', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('271', '141', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('272', '142', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('273', '143', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('274', '144', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('275', '145', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('276', '146', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('277', '147', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('278', '148', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('279', '149', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('280', '150', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('281', '151', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('282', '152', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('283', '153', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('284', '154', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('285', '155', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('286', '156', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('287', '157', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('288', '158', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('289', '159', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('290', '160', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('291', '161', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('292', '162', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('293', '163', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('294', '164', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('295', '165', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('296', '166', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('297', '167', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('298', '168', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('299', '169', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('300', '170', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('301', '171', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('302', '172', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('303', '173', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('304', '174', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('305', '175', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('306', '176', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('307', '177', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('308', '178', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('309', '179', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('310', '180', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('311', '181', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('312', '182', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('313', '183', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('314', '184', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('315', '185', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('316', '186', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('317', '187', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('318', '188', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('319', '189', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('320', '190', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('321', '191', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('322', '192', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('323', '193', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('324', '194', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('325', '195', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('326', '196', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('327', '197', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('328', '198', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('329', '199', '预留占位', '1');
INSERT INTO `hisi_admin_menu_lang` VALUES ('330', '200', '预留占位', '1');

-- -----------------------------
-- Table structure for `hisi_admin_module`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_module`;
CREATE TABLE `hisi_admin_module` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '系统模块',
  `name` varchar(50) NOT NULL COMMENT '模块名(英文)',
  `identifier` varchar(100) NOT NULL COMMENT '模块标识(模块名(字母).开发者标识.module)',
  `title` varchar(50) NOT NULL COMMENT '模块标题',
  `intro` varchar(255) NOT NULL COMMENT '模块简介',
  `author` varchar(100) NOT NULL COMMENT '作者',
  `icon` varchar(80) NOT NULL DEFAULT 'aicon ai-mokuaiguanli' COMMENT '图标',
  `version` varchar(20) NOT NULL COMMENT '版本号',
  `url` varchar(255) NOT NULL COMMENT '链接',
  `sort` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0未安装，1未启用，2已启用',
  `default` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '默认模块(只能有一个)',
  `config` text NOT NULL COMMENT '配置',
  `app_id` varchar(30) NOT NULL DEFAULT '0' COMMENT '应用市场ID(0本地)',
  `app_keys` varchar(200) DEFAULT '' COMMENT '应用秘钥',
  `theme` varchar(50) NOT NULL DEFAULT 'default' COMMENT '主题模板',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE,
  UNIQUE KEY `identifier` (`identifier`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 模块';

-- -----------------------------
-- Records of `hisi_admin_module`
-- -----------------------------
INSERT INTO `hisi_admin_module` VALUES ('1', '1', 'admin', 'admin.hisiphp.module', '系统管理模块', '系统核心模块，用于后台各项管理功能模块及功能拓展', 'HisiPHP官方出品', '', '1.0.0', 'http://www.hisiphp.com', '0', '2', '0', '', '0', '', 'default', '1489998096', '1489998096');
INSERT INTO `hisi_admin_module` VALUES ('2', '1', 'index', 'index.hisiphp.module', '系统默认模块', '仅供前端插件访问和应用市场推送安装，禁止在此模块下面开发任何东西。', 'HisiPHP官方出品', '', '1.0.0', 'http://www.hisiphp.com', '0', '2', '0', '', '0', '', 'default', '1489998096', '1489998096');
INSERT INTO `hisi_admin_module` VALUES ('3', '1', 'install', 'install.hisiphp.module', '系统安装模块', '系统安装模块，勿动。', 'HisiPHP官方出品', '', '1.0.0', 'http://www.hisiphp.com', '0', '2', '0', '', '0', '', 'default', '1489998096', '1489998096');
INSERT INTO `hisi_admin_module` VALUES ('4', '0', 'test', 'test.mc.module', '测试模块', '测试模块', 'mc', '/hisiphp/static/app_icon/test.png', '1.0.0', '', '0', '0', '0', '', '0', '', 'default', '1556013790', '1556013790');

-- -----------------------------
-- Table structure for `hisi_admin_plugins`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_plugins`;
CREATE TABLE `hisi_admin_plugins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL COMMENT '插件名称(英文)',
  `title` varchar(32) NOT NULL COMMENT '插件标题',
  `icon` varchar(64) NOT NULL COMMENT '图标',
  `intro` text NOT NULL COMMENT '插件简介',
  `author` varchar(32) NOT NULL COMMENT '作者',
  `url` varchar(255) NOT NULL COMMENT '作者主页',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '插件唯一标识符',
  `config` text NOT NULL COMMENT '插件配置',
  `app_id` varchar(30) NOT NULL DEFAULT '0' COMMENT '应用市场ID(0本地)',
  `app_keys` varchar(200) DEFAULT '' COMMENT '应用秘钥',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 插件表';

-- -----------------------------
-- Records of `hisi_admin_plugins`
-- -----------------------------
INSERT INTO `hisi_admin_plugins` VALUES ('1', '0', 'hisiphp', '系统基础信息', '/plugins/hisiphp/hisiphp.png', '后台首页展示系统基础信息和开发团队信息', 'HisiPHP', 'http://www.hisiphp.com', '1.0.0', 'hisiphp.hisiphp.plugins', '', '0', '', '1509379331', '1509379331', '0', '2');

-- -----------------------------
-- Table structure for `hisi_admin_role`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_role`;
CREATE TABLE `hisi_admin_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '角色名称',
  `intro` varchar(200) NOT NULL COMMENT '角色简介',
  `auth` text NOT NULL COMMENT '角色权限',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 管理角色';

-- -----------------------------
-- Records of `hisi_admin_role`
-- -----------------------------
INSERT INTO `hisi_admin_role` VALUES ('1', '超级管理员', '拥有系统最高权限', '0', '1489411760', '0', '1');
INSERT INTO `hisi_admin_role` VALUES ('2', '系统管理员', '拥有系统管理员权限', '{\"0\":\"1\",\"1\":\"4\",\"2\":\"25\",\"3\":\"24\",\"4\":\"105\",\"5\":\"106\",\"6\":\"113\",\"7\":\"205\",\"8\":\"206\",\"9\":\"208\",\"10\":\"209\",\"11\":\"210\",\"12\":\"211\",\"13\":\"213\",\"14\":\"215\",\"15\":\"216\",\"16\":\"217\",\"17\":\"2\",\"18\":\"6\",\"19\":\"10\",\"20\":\"60\",\"21\":\"61\",\"22\":\"62\",\"23\":\"63\",\"24\":\"91\",\"25\":\"11\",\"26\":\"55\",\"27\":\"56\",\"28\":\"57\",\"29\":\"58\",\"30\":\"59\",\"31\":\"12\",\"32\":\"26\",\"33\":\"27\",\"34\":\"28\",\"35\":\"29\",\"36\":\"30\",\"37\":\"31\",\"38\":\"32\",\"39\":\"13\",\"40\":\"33\",\"41\":\"34\",\"42\":\"35\",\"43\":\"36\",\"44\":\"14\",\"45\":\"37\",\"46\":\"38\",\"47\":\"39\",\"48\":\"40\",\"49\":\"41\",\"53\":\"16\",\"54\":\"78\",\"55\":\"79\",\"57\":\"84\",\"58\":\"85\",\"59\":\"86\",\"60\":\"87\",\"61\":\"88\",\"62\":\"89\",\"69\":\"7\",\"70\":\"20\",\"71\":\"75\",\"72\":\"76\",\"73\":\"77\",\"74\":\"21\",\"75\":\"90\",\"76\":\"70\",\"77\":\"71\",\"78\":\"72\",\"79\":\"73\",\"80\":\"74\",\"81\":\"8\",\"84\":\"17\",\"85\":\"65\",\"86\":\"66\",\"87\":\"67\",\"88\":\"68\",\"92\":\"94\",\"93\":\"95\",\"98\":\"18\",\"100\":\"42\",\"101\":\"43\",\"103\":\"45\",\"105\":\"47\",\"106\":\"48\",\"107\":\"49\",\"109\":\"19\",\"116\":\"80\",\"117\":\"81\",\"118\":\"82\",\"119\":\"83\",\"120\":\"3\",\"121\":\"5\"}', '1489411760', '1560231824', '1');
INSERT INTO `hisi_admin_role` VALUES ('3', '微信号管理', '微信号管理', '{\"0\":\"1\",\"1\":\"4\",\"3\":\"24\",\"10\":\"209\",\"11\":\"210\",\"13\":\"213\",\"14\":\"215\",\"15\":\"216\",\"16\":\"217\",\"17\":\"218\",\"18\":\"2\",\"19\":\"6\",\"45\":\"14\",\"50\":\"41\"}', '1560224547', '1560318033', '1');

-- -----------------------------
-- Table structure for `hisi_admin_user`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_admin_user`;
CREATE TABLE `hisi_admin_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '角色ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(64) NOT NULL,
  `nick` varchar(50) NOT NULL COMMENT '昵称',
  `mobile` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL COMMENT '邮箱',
  `auth` text NOT NULL COMMENT '权限',
  `iframe` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0默认，1框架',
  `theme` varchar(30) NOT NULL DEFAULT '1' COMMENT '主题',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `last_login_ip` varchar(128) NOT NULL COMMENT '最后登陆IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登陆时间',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 管理用户';

-- -----------------------------
-- Records of `hisi_admin_user`
-- -----------------------------
INSERT INTO `hisi_admin_user` VALUES ('1', '1', 'admin', '$2y$10$A12GfpVpYBp184LCtdo/HeFh3EZl7xeCv.fNIrhKtA/Gkj/DHUpr.', '超级管理员', '', '', '', '0', '0', '1', '113.65.228.131', '1560475823', '1556013069', '1560475823');
INSERT INTO `hisi_admin_user` VALUES ('2', '3', 'user01', '$2y$10$ZwYRfWyr2z2PKOv0XebI9.z6bjgj79hPwMHm04nnTxLZT38RufFzC', 'user01', '', '', '', '0', '1', '1', '113.65.228.131', '1560318193', '1560224589', '1560318193');
INSERT INTO `hisi_admin_user` VALUES ('3', '3', 'user02', '$2y$10$VHhO3sKr69tzhjVeFOabfeCRVX3FrjNwFTFeM8rOXqpvN5V8wHlQy', 'user02', '', '', '{\"0\":\"1\",\"1\":\"4\",\"3\":\"24\",\"10\":\"209\",\"11\":\"210\",\"12\":\"211\",\"13\":\"212\",\"14\":\"213\",\"15\":\"215\",\"16\":\"216\",\"17\":\"217\",\"18\":\"2\",\"19\":\"6\",\"45\":\"14\",\"50\":\"41\"}', '0', '1', '1', '113.65.228.245', '1560236008', '1560225984', '1560236008');

-- -----------------------------
-- Table structure for `hisi_common_config`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_common_config`;
CREATE TABLE `hisi_common_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) DEFAULT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- -----------------------------
-- Records of `hisi_common_config`
-- -----------------------------
INSERT INTO `hisi_common_config` VALUES ('1', '15802011993', '443235363', '广东省广州市天河区黄村福元南路4号1325');

-- -----------------------------
-- Table structure for `hisi_header1`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_header1`;
CREATE TABLE `hisi_header1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `intro` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- -----------------------------
-- Records of `hisi_header1`
-- -----------------------------
INSERT INTO `hisi_header1` VALUES ('1', 'goodsa', '信息服务业务（仅含互联网）', '“信息服务业务（仅含互联网）”资质，官方标准称为增值电信业务经营许可证(仅限互联网信息服务)。业内俗称为IC许可证、经营性ICP。其详细业务范围是指，通过信息采集、开发、处理和信息平台的建设，通过公用通信网或互联网向用户提供信息服务的业务，而必须取得的核发业务准入资质。');
INSERT INTO `hisi_header1` VALUES ('2', 'goodsb', '游戏类文网文', '游戏类网络文化经营许可证是指通过网络运行或经营网络游戏产品等进行商业化营利为目的，通过向上网用户收费或者电子商务、广告、赞助等方式获取利益，提供互联网文化游戏产品及服务的活动，需得到当地文化局的同意或认可，由文化局颁发游戏类网络文化经营许可证牌照，简称游戏类文网文证。');
INSERT INTO `hisi_header1` VALUES ('3', 'goodsc', '游戏版号', '游戏版号是游戏版权号的简称，是由国家新闻出版广电总局审核发布的对于游戏根据（著作权（游戏软件著作权、含网络游戏）法）和（计算机游戏软件保护条例）等法律法规的规定，游戏软件厂商或者个人作者开发的游戏软件在开发完成后就受到著作权（游戏软件著作权，含网络游戏）法的保护。游戏版号（也就是游戏出版备案）俗称电子出版物号，简称ISBN，普遍的有光盘发行号，书号。');
INSERT INTO `hisi_header1` VALUES ('4', 'goodsd', '互联网接入服务业务', 'ISP互联网接入服务业务是为各类用户提供互联网的服务。企业从事ISP业务就需要申请ISP许可证，简称ISP证、isp资质、isp牌照，属于第一类增值电信业务的互联网接入服务的业务。');
INSERT INTO `hisi_header1` VALUES ('5', 'reg', '工商注册', '主要面向中小创业者提供公司注册、名称变更、法人变更、资本变更和工商年检等快捷专业的企业服务。公司注册只需要￥668，超高性价比服务套餐！！');
INSERT INTO `hisi_header1` VALUES ('6', 'tax', '会计代理', '主要面向中小型企业、私营、股份制等在粤投资设立的办事机构及有发展潜能的创业家，并由经验丰富、业务熟练、责任心强的会计专业团队为您提供优质的会计服务。');
INSERT INTO `hisi_header1` VALUES ('7', 'wangzhanjianshe', '网站建设', '秘书先生致力于创造专业化、个性化、品牌化的网络服务。目前，秘书先生的核心产品包括“云建站系统、微商城系统、公众号系统、手机APP应用开发、微信小程序开发、一物一码、企业VI设计、域名注册、企业邮箱、虚拟主机和搜索引擎优化SEO多元化的互联网应用服务。');

-- -----------------------------
-- Table structure for `hisi_order`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_order`;
CREATE TABLE `hisi_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '姓名',
  `mobie` varchar(255) NOT NULL COMMENT '电话号码',
  `address` text NOT NULL COMMENT '详细地址',
  `freetime` varchar(55) NOT NULL COMMENT '空闲时间',
  `ctime` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hisi_order`
-- -----------------------------
INSERT INTO `hisi_order` VALUES ('1', '哒哒', '13144126820', '车陂', '', '10');
INSERT INTO `hisi_order` VALUES ('2', '哒哒', '13144126820', '车陂', '', '10');
INSERT INTO `hisi_order` VALUES ('3', '阿斯钢', '13144126820', '河北省石家庄市长安区河北省石家庄市长安区sad郭德纲', '14：00~15：00', '0');
INSERT INTO `hisi_order` VALUES ('4', '阿斯钢', '13144126822', '河北省石家庄市长安区河北省石家庄市长安区河北省石家庄市长安区sad郭德纲', '14：00~15：00', '1560480038');

-- -----------------------------
-- Table structure for `hisi_shield`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_shield`;
CREATE TABLE `hisi_shield` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(55) NOT NULL COMMENT '标题',
  `closedarea` text NOT NULL COMMENT '屏蔽地区',
  `ctime` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `hisi_shield`
-- -----------------------------
INSERT INTO `hisi_shield` VALUES ('1', '穿山甲', '北京市,广州市,天津市,济南市,成都市,长沙市,金华市,深圳市,上海市', '2019-05-22 14:38:47');
INSERT INTO `hisi_shield` VALUES ('2', '站内', '', '2019-05-22 14:49:46');

-- -----------------------------
-- Table structure for `hisi_swiper_index`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_swiper_index`;
CREATE TABLE `hisi_swiper_index` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;


-- -----------------------------
-- Table structure for `hisi_url`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_url`;
CREATE TABLE `hisi_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `url` varchar(255) NOT NULL COMMENT '域名',
  `userId` int(11) NOT NULL COMMENT '用户id',
  `type` int(11) NOT NULL COMMENT '0开启，1关闭',
  `wctype` int(255) NOT NULL DEFAULT '0' COMMENT '0屏蔽，1换微信，2全部',
  `shieldTyep` int(5) NOT NULL DEFAULT '1' COMMENT '1穿山甲，2站内',
  `ctime` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `hisi_url`
-- -----------------------------
INSERT INTO `hisi_url` VALUES ('1', 'cx2k.szjssm.cn', 'http://cx2k.szjssm.cn', '2', '0', '1', '1', '2019-05-22 13:50:02');
INSERT INTO `hisi_url` VALUES ('2', 'cx2k.szjssm.cn', 'http://cx2k.szjssm.cn', '3', '0', '1', '1', '2019-05-22 13:50:02');

-- -----------------------------
-- Table structure for `hisi_wechat`
-- -----------------------------
DROP TABLE IF EXISTS `hisi_wechat`;
CREATE TABLE `hisi_wechat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `urlid` int(11) NOT NULL COMMENT '域名id',
  `name` varchar(255) NOT NULL COMMENT '微信号',
  `url` varchar(255) NOT NULL COMMENT '二维码地址',
  `ctime` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `hisi_wechat`
-- -----------------------------
INSERT INTO `hisi_wechat` VALUES ('1', '1', '111111', '1.jpg', '2019-05-27 18:41:31');
INSERT INTO `hisi_wechat` VALUES ('2', '1', 'fgkjln', '/upload/iamge/image/99/4a1e50a49306314873a10290cc5237.gif', '2019-05-27 18:41:31');
INSERT INTO `hisi_wechat` VALUES ('6', '2', 'jfweix2991', '', '2019-06-11 14:29:47');
